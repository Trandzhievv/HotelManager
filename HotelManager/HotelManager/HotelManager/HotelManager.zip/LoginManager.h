#pragma once
#include "User.h"
#include "MyVector.hpp"

class LoginManager {
public:
    static User* login();  
};

