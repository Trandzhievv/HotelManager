#pragma once

enum class RoomType {
    SINGLE,
    DOUBLE,
    LUXURY,
    CONFERENCE,
    APARTMENT
};

