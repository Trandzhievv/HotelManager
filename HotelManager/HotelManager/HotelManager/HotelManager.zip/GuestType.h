#pragma once

enum class GuestType {
    REGULAR,
    GOLD,
    PLATINUM
};


